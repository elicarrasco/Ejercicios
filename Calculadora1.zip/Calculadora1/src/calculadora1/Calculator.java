/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculadora1;

/**
 *
 * @author Elizabeth Carrasco
 */
public class Calculator {
    //se agrega el metodo de suma, resta, multiplicacion y division
    
    public int add(int a, int b){
        return a+b;
    }
    public int subtract(int a, int b){
        return a-b;
    }
    public int multiply(int a, int b){
        return a*b;
    }
    public int divide(int a, int b){
        if(b==0){
            throw new IllegalArgumentException("No es posible dividir por cero");
        }
        return a/b;
    }    
}
